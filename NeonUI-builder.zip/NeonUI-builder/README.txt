NEON UI for Minecraft Bedrock - build steps
============================================

What it does: recolors Minecraft's own buttons, panels, inventory slots,
hotbar and toggles into a neon purple / magenta / cyan look. Marketplace and
Dressing Room textures are skipped.

Limit: only screens that still use the old JSON UI can change. Newer Ore UI
screens (Play, Create World, Achievements, and most likely the Dressing Room
and Marketplace) are hardcoded by Mojang and no resource pack can restyle them.

BUILD IN A FRESH GITHUB CODESPACE
1. Go to github.com/codespaces and tap "New codespace" (Blank template).
2. When it opens, upload NeonUI-builder.zip (Explorer panel -> "..." -> Upload,
   or drag the file in).
3. Open the terminal and run:
       unzip NeonUI-builder.zip
       cd NeonUI-builder
       python3 build_neon_ui.py
4. Wait for "Done -> .../NeonUI.mcpack".
5. In the Explorer, long-press / right-click NeonUI.mcpack -> Download.

INSTALL
6. Open the downloaded NeonUI.mcpack with Minecraft (it imports itself).
7. Settings -> Global Resources -> Neon UI -> Activate.

If step 3 says it could not download the vanilla textures, run it again with
a vanilla textures/ui folder:
       python3 build_neon_ui.py --src /path/to/resource_pack/textures/ui

Tip: put Neon UI at the TOP of your resource pack list so it wins over others.
