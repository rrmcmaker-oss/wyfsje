#!/usr/bin/env python3
"""
Neon UI builder for Minecraft Bedrock.

Takes Mojang's own vanilla UI textures, recolors the buttons / panels / slots /
hotbar / toggles into a neon palette (same file names + same sizes, so nothing
stretches), and packs the result into NeonUI.mcpack.

Textures that belong to the Marketplace or the Dressing Room are skipped.

Usage:
    python3 build_neon_ui.py                 # downloads vanilla textures itself
    python3 build_neon_ui.py --src PATH      # use your own textures/ui folder
"""
import argparse
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    for extra in ([], ["--break-system-packages"], ["--user"]):
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "pillow", *extra])
            break
        except subprocess.CalledProcessError:
            continue
    from PIL import Image

HERE = Path(__file__).resolve().parent
OUT_PACK = HERE / "NeonUI"
OUT_FILE = HERE / "NeonUI.mcpack"
WORK = HERE / "vanilla_src"

# Anything with these words anywhere in its path is left alone.
EXCLUDE = re.compile(r"(store|market|persona|dressing|character_creator|skin|coin)")

# First match on the file name wins.
GROUPS = [
    ("slot", re.compile(r"(cell|slot|hotbar|selected)")),
    ("control", re.compile(r"(toggle|slider|scroll|checkbox|dropdown|stepper|edit_box|text_box|textbox|(^|_)tabs?(_|$|\d))")),
    ("button", re.compile(r"(button|btn)")),
    ("panel", re.compile(r"(dialog_background|background|panel|frame|window)")),
]

# Gradient maps: (brightness 0..1, hex colour). Dark pixels -> first colour,
# bright pixels -> last colour. Hover/pressed states keep their relative
# brightness, so they light up differently on their own.
PALETTES = {
    "button": [(0.00, "#10002a"), (0.35, "#7a1fff"), (0.70, "#ff2bd6"), (1.00, "#00f0ff")],
    "control": [(0.00, "#001a24"), (0.45, "#0090ff"), (0.80, "#00f0ff"), (1.00, "#39ff14")],
    "panel": [(0.00, "#02000c"), (0.45, "#1a0638"), (0.80, "#5a1aa8"), (1.00, "#00e5ff")],
    "slot": [(0.00, "#060014"), (0.50, "#1a0a3c"), (0.75, "#7a1fff"), (1.00, "#00f0ff")],
}


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def make_luts(stops):
    """Build three 256-entry lookup tables (R, G, B) from gradient stops."""
    pts = [(p, hex_to_rgb(c)) for p, c in stops]
    luts = ([], [], [])
    for v in range(256):
        t = v / 255.0
        for i in range(len(pts) - 1):
            (p0, c0), (p1, c1) = pts[i], pts[i + 1]
            if t <= p1 or i == len(pts) - 2:
                f = 0.0 if p1 == p0 else min(max((t - p0) / (p1 - p0), 0.0), 1.0)
                for ch in range(3):
                    luts[ch].append(int(round(c0[ch] + (c1[ch] - c0[ch]) * f)))
                break
    return luts


LUTS = {name: make_luts(stops) for name, stops in PALETTES.items()}


def classify(rel_path):
    low = rel_path.as_posix().lower()
    if EXCLUDE.search(low):
        return None
    stem = rel_path.stem.lower()
    for name, rx in GROUPS:
        if rx.search(stem):
            return name
    return None


def recolor(src, dst, group):
    img = Image.open(src).convert("RGBA")
    alpha = img.getchannel("A")
    gray = img.convert("L")
    r, g, b = (gray.point(lut) for lut in LUTS[group])
    out = Image.merge("RGBA", (r, g, b, alpha))
    dst.parent.mkdir(parents=True, exist_ok=True)
    out.save(dst)


def run(cmd, **kw):
    return subprocess.run(cmd, check=False, text=True, capture_output=True, **kw)


def has_pngs(folder):
    return folder.is_dir() and any(folder.rglob("*.png"))


def fetch_vanilla():
    """Get Mojang's vanilla textures/ui folder. Returns its path."""
    target = WORK / "resource_pack" / "textures" / "ui"
    if has_pngs(target):
        return target

    # Try 1: sparse clone of just textures/ui from the public samples repo.
    print("Downloading vanilla UI textures (sparse clone)...")
    shutil.rmtree(WORK, ignore_errors=True)
    r = run(["git", "clone", "--depth", "1", "--filter=blob:none", "--sparse",
             "https://github.com/Mojang/bedrock-samples.git", str(WORK)])
    if r.returncode == 0:
        run(["git", "-C", str(WORK), "sparse-checkout", "set", "resource_pack/textures/ui"])
        if has_pngs(target):
            return target
    else:
        print(r.stderr.strip())

    # Try 2: latest release "full" zip through the GitHub CLI (preinstalled in Codespaces).
    print("Sparse clone gave no textures, trying the release download...")
    shutil.rmtree(WORK, ignore_errors=True)
    WORK.mkdir(parents=True)
    r = run(["gh", "release", "download", "-R", "Mojang/bedrock-samples",
             "-p", "*full*", "-D", str(WORK)])
    if r.returncode != 0:
        print(r.stderr.strip())
    for z in WORK.glob("*.zip"):
        with zipfile.ZipFile(z) as zf:
            zf.extractall(WORK / "release")
    for cand in (WORK / "release").rglob("ui"):
        if cand.parent.name == "textures" and has_pngs(cand):
            return cand

    sys.exit("Could not download the vanilla textures. Re-run with --src PATH "
             "pointing at a vanilla resource_pack/textures/ui folder.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", help="path to a vanilla textures/ui folder")
    args = ap.parse_args()

    src = Path(args.src).resolve() if args.src else fetch_vanilla()
    if not has_pngs(src):
        sys.exit(f"No PNG files found in {src}")

    shutil.rmtree(OUT_PACK, ignore_errors=True)
    (OUT_PACK / "textures" / "ui").mkdir(parents=True)
    shutil.copy(HERE / "manifest.json", OUT_PACK / "manifest.json")
    shutil.copy(HERE / "pack_icon.png", OUT_PACK / "pack_icon.png")

    counts = {k: 0 for k in PALETTES}
    skipped_excluded = 0
    for png in sorted(src.rglob("*.png")):
        rel = png.relative_to(src)
        group = classify(rel)
        if group is None:
            if EXCLUDE.search(rel.as_posix().lower()):
                skipped_excluded += 1
            continue
        try:
            recolor(png, OUT_PACK / "textures" / "ui" / rel, group)
            counts[group] += 1
        except Exception as e:  # keep going if one odd file fails
            print(f"skip {rel}: {e}")

    total = sum(counts.values())
    if total == 0:
        sys.exit("Nothing matched, so no pack was made.")

    if OUT_FILE.exists():
        OUT_FILE.unlink()
    with zipfile.ZipFile(OUT_FILE, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(OUT_PACK.rglob("*")):
            if f.is_file():
                zf.write(f, f.relative_to(OUT_PACK).as_posix())

    print(f"\nRecolored {total} textures: " + ", ".join(f"{k} {v}" for k, v in counts.items()))
    print(f"Left alone (Marketplace / Dressing Room names): {skipped_excluded}")
    print(f"Done -> {OUT_FILE}")


if __name__ == "__main__":
    main()
